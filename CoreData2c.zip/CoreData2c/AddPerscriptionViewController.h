//
//  AddPerscriptionViewController.h
//  CoreData2
//
//  Created by Vladamir Nedelko on 11/19/13.
//  Copyright (c) 2013 Vladamir Nedelko. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CoreViewController.h"
#import "Patient.h"
#import "Perscription.h"

@interface AddPerscriptionViewController : CoreViewController

// represent relationship of perscription and patient

@property (nonatomic, strong)Patient *perscriptionsPatient;

@property (nonatomic, strong)Perscription *addPerscription;

@end
