//
//  CoreViewController.m
//  CoreData2
//
//  Created by Vladamir Nedelko on 11/19/13.
//  Copyright (c) 2013 Vladamir Nedelko. All rights reserved.
//

#import "CoreViewController.h"
#import "AppDelegate.h"

@interface CoreViewController ()

@property (nonatomic, strong) NSManagedObjectContext *managedObjectContext;

@end

@implementation CoreViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

        // creating a reference to managedObjectContext
- (NSManagedObjectContext*)managedObjectContext{
    
    return [(AppDelegate*)[[UIApplication sharedApplication] delegate] managedObjectContext];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)cancelAndDismiss{

    [self.managedObjectContext rollback];
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)saveAndDismiss{

    NSError *error = nil;
    if([self.managedObjectContext hasChanges]){
    
        if (![self.managedObjectContext save:&error]){
            NSLog(@"Error %@", [error localizedDescription]);
        }else{
            NSLog(@"Save Succeeded");
        }
    }
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

// Core Data Part 2 - Coding the Patient's View Controller

@end



