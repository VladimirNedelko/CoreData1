//
//  PatientstableViewController.h
//  CoreData2
//
//  Created by Vladamir Nedelko on 11/19/13.
//  Copyright (c) 2013 Vladamir Nedelko. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Patient.h"

@interface PatientstableViewController : UITableViewController<NSFetchedResultsControllerDelegate>



@end
