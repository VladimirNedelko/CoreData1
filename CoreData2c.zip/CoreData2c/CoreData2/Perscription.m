//
//  Perscription.m
//  CoreData2b
//
//  Created by Vladamir Nedelko on 11/25/13.
//  Copyright (c) 2013 Vladamir Nedelko. All rights reserved.
//

#import "Perscription.h"
#import "Patient.h"


@implementation Perscription

@dynamic perscriptionName;
@dynamic perscriptionInstructions;
@dynamic patient;

@end
