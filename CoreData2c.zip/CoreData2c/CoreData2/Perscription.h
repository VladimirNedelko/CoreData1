//
//  Perscription.h
//  CoreData2b
//
//  Created by Vladamir Nedelko on 11/25/13.
//  Copyright (c) 2013 Vladamir Nedelko. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Patient;

@interface Perscription : NSManagedObject

@property (nonatomic, retain) NSString * perscriptionName;
@property (nonatomic, retain) NSString * perscriptionInstructions;
@property (nonatomic, retain) Patient *patient;

@end
