//
//  Patient.h
//  CoreData2b
//
//  Created by Vladamir Nedelko on 11/25/13.
//  Copyright (c) 2013 Vladamir Nedelko. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface Patient : NSManagedObject

@property (nonatomic, retain) NSString * patientFirstName;
@property (nonatomic, retain) NSString * patientLastName;
@property (nonatomic, retain) NSSet *perscriptions;
@end

@interface Patient (CoreDataGeneratedAccessors)

- (void)addPerscriptionsObject:(NSManagedObject *)value;
- (void)removePerscriptionsObject:(NSManagedObject *)value;
- (void)addPerscriptions:(NSSet *)values;
- (void)removePerscriptions:(NSSet *)values;

@end
