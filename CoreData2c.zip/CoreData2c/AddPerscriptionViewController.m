//
//  AddPerscriptionViewController.m
//  CoreData2
//
//  Created by Vladamir Nedelko on 11/19/13.
//  Copyright (c) 2013 Vladamir Nedelko. All rights reserved.
//

#import "AddPerscriptionViewController.h"
#import "PerscriptionsViewController.h"

@interface AddPerscriptionViewController ()

@property (weak, nonatomic) IBOutlet UITextField *perscriptionName;

@property (weak, nonatomic) IBOutlet UITextField *perscriptionInstricions;

- (IBAction)cancel:(UIBarButtonItem *)sender;

- (IBAction)save:(UIBarButtonItem *)sender;


@end

@implementation AddPerscriptionViewController

@synthesize addPerscription, perscriptionsPatient;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)cancel:(UIBarButtonItem *)sender {
    
    [super cancelAndDismiss];
}

- (IBAction)save:(UIBarButtonItem *)sender {
    
    // db path
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    NSString * pth = paths[0];
    NSLog(@" path %@", pth); 
    
    addPerscription.patient = perscriptionsPatient;
    addPerscription.perscriptionName = _perscriptionName.text; // textfield
    addPerscription.perscriptionInstructions = _perscriptionInstricions.text; 
    
    [super saveAndDismiss];
}


@end


