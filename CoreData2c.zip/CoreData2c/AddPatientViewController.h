//
//  AddPatientViewController.h
//  CoreData2
//
//  Created by Vladamir Nedelko on 11/19/13.
//  Copyright (c) 2013 Vladamir Nedelko. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CoreViewController.h" 
#import "Patient.h"


@interface AddPatientViewController : CoreViewController

    
@property (nonatomic, strong) Patient *addPatient;

@end
